import type { SubdivMesh } from './types';
/**
 * A stencil table: every refined vertex expressed directly as a sparse
 * affine combination of *control cage* vertices. This is the web analogue
 * of the plugin's Far::StencilTable — the expensive topological refinement
 * runs once, then animated control points re-evaluate in a single sparse
 * matrix-vector product per frame.
 */
export interface StencilTable {
    offsets: Uint32Array;
    indices: Uint32Array;
    weights: Float32Array;
    /** Number of refined vertices (rows). */
    rowCount: number;
    /** Number of control cage vertices (columns). */
    controlVertexCount: number;
}
/** A precomputed subdivision surface: static refined topology + stencils. */
export interface RefinedSurface {
    /** Refined mesh at the requested level, positions evaluated from the cage. */
    mesh: SubdivMesh;
    table: StencilTable;
    levels: number;
}
/**
 * Refine `cage` by `levels` and return the static topology plus a stencil
 * table mapping control points directly to every refined vertex.
 */
export declare function buildRefinedSurface(cage: SubdivMesh, levels: number): RefinedSurface;
/**
 * Per-frame evaluation: refinedPositions = table * controlPositions.
 * Pass `out` (e.g. the refined mesh's own positions array) to avoid
 * allocation in the animation loop.
 */
export declare function applyStencils(table: StencilTable, controlPositions: Float32Array, out?: Float32Array): Float32Array;
//# sourceMappingURL=stencils.d.ts.map