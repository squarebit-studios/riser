import type { SubdivMesh } from '../core/types';
/** Unit cube with per-face UVs. `creaseSharpness` > 0 creases all 12 edges. */
export declare function cube(creaseSharpness?: number): SubdivMesh;
/** Open-ended quad cylinder cage — demonstrates boundary rules. */
export declare function openCylinder(segments?: number, rings?: number, radius?: number, height?: number): SubdivMesh;
/** Coarse quad torus cage. */
export declare function torusCage(major?: number, minor?: number, R?: number, r?: number): SubdivMesh;
//# sourceMappingURL=shapes.d.ts.map