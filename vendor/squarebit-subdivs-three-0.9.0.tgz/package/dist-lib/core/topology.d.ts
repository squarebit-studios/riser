import type { SubdivMesh } from './types';
/**
 * Edge connectivity derived from a face list. Built once per subdivision
 * level (the analogue of the plugin's Far topology refinement step).
 */
export interface EdgeTopology {
    edgeCount: number;
    /** 2 per edge: [v0, v1] with v0 < v1. */
    edgeVertices: Uint32Array;
    /** 2 per edge: adjacent face indices, -1 if absent. Only the first two are kept. */
    edgeFaces: Int32Array;
    /** Number of faces touching each edge (may exceed 2 for non-manifold input). */
    edgeFaceCounts: Uint8Array;
    /**
     * Per-corner edge index for the edge running corner(i) -> corner(i+1)
     * within its face. Aligned with `faceVertexIndices`.
     */
    cornerEdges: Uint32Array;
    /** Offset of each face's first corner (prefix sum of faceVertexCounts, plus total at the end). */
    faceOffsets: Uint32Array;
    /**
     * Per-edge sharpness resolved from the mesh's crease set. Boundary and
     * non-manifold edges are forced to Infinity (always sharp), matching the
     * plugin's boundary interpolation behavior.
     */
    edgeSharpness: Float32Array;
}
export declare function buildEdgeTopology(mesh: SubdivMesh): EdgeTopology;
//# sourceMappingURL=topology.d.ts.map