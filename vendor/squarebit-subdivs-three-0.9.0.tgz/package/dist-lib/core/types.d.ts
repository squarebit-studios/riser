/**
 * Core mesh types for the subdivision kernel. This layer has no three.js
 * dependency — it mirrors the plugin's split between the OSD-facing topology
 * code and the engine-facing render layer.
 */
/** Semi-sharp edge creases. `edges` holds vertex-index pairs (2 per crease). */
export interface CreaseSet {
    /** Flattened vertex-index pairs: [a0, b0, a1, b1, ...] */
    edges: Uint32Array;
    /** One sharpness per pair. 0 = smooth, >=1 decays one level per subdivision, Infinity = always sharp. */
    sharpness: Float32Array;
}
/** Semi-sharp vertex corners. */
export interface CornerSet {
    vertices: Uint32Array;
    sharpness: Float32Array;
}
/**
 * A polygonal control cage / refined mesh. Faces may be arbitrary n-gons at
 * level 0; every face is a quad after one round of Catmull-Clark.
 */
export interface SubdivMesh {
    /** xyz per vertex. */
    positions: Float32Array;
    /** Vertex count of each face. */
    faceVertexCounts: Uint32Array;
    /** Flattened per-face vertex indices ("corners"). */
    faceVertexIndices: Uint32Array;
    /**
     * Optional face-varying UVs: 2 floats per corner, aligned with
     * `faceVertexIndices`. Interpolated bilinearly across levels for now
     * (OSD FVAR_LINEAR_ALL); smooth face-varying rules are on the roadmap.
     */
    uvs?: Float32Array;
    /**
     * Optional per-face material slot (the plugin's multi-section analogue).
     * Survives refinement (children inherit their parent face's slot) and
     * becomes three.js geometry groups in the render layer.
     */
    faceMaterialIndices?: Uint32Array;
    creases?: CreaseSet;
    corners?: CornerSet;
}
/** Counts helper used by stats displays and tests. */
export declare function meshCounts(mesh: SubdivMesh): {
    vertices: number;
    faces: number;
    corners: number;
};
//# sourceMappingURL=types.d.ts.map