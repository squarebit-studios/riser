import type { SubdivMesh } from './types';
/**
 * Area-weighted smooth vertex normals via Newell's method per face.
 * Robust for arbitrary planar/non-planar n-gons.
 *
 * All-quad meshes (every refined level after the first) take a fast path:
 * for any quad — planar or not — the Newell normal equals the cross
 * product of its diagonals, so each face costs one cross product instead
 * of four edge terms, with identical accumulation weights.
 */
export declare function computeVertexNormals(mesh: SubdivMesh, out?: Float32Array): Float32Array;
//# sourceMappingURL=normals.d.ts.map