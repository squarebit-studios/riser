import type { SubdivMesh } from './types';
/**
 * Heuristic quad recovery: pair adjacent triangles back into quads.
 *
 * Triangulated sources (glTF has no n-gon support) subdivide correctly but
 * carry the triangulation into the surface — every tri becomes three quads
 * with an extraordinary vertex at its center, which reads as shading
 * artifacts on what was authored as a quad grid. Merging coplanar,
 * well-shaped triangle pairs first recovers the authored Catmull-Clark
 * look. This is the web analogue of the plugin's editor-time quad
 * recovery, adapted for sources whose authored topology is unavailable
 * (mirrors Blender's tris-to-quads heuristic).
 *
 * Positions and vertex indices are untouched — only faces (and their
 * face-varying UVs) are rewritten — so creases, corners, and skin
 * bindings pass through unchanged.
 */
export interface QuadRecoveryOptions {
    /** Max angle between the two triangle normals, radians (default 40°). */
    maxFaceAngle?: number;
    /** Max deviation of any resulting quad corner from 90°, radians (default 40°). */
    maxCornerDeviation?: number;
    /** Max UV mismatch allowed across the removed diagonal (default 1e-4). */
    uvTolerance?: number;
}
export declare function recoverQuads(mesh: SubdivMesh, options?: QuadRecoveryOptions): SubdivMesh;
//# sourceMappingURL=quadRecovery.d.ts.map