/**
 * CPU linear-blend skinning over flat arrays — no three.js dependency.
 *
 * Replicates three.js's skinning shader exactly:
 *   skinVertex = bindMatrix * position
 *   skinned    = Σ weight_i * boneMatrix_i * skinVertex
 *   out        = (bindMatrixInverse * skinned).xyz
 *
 * In the subdivision pipeline this runs on the *control cage* only (the
 * plugin's architecture): skin a few hundred cage vertices on the CPU,
 * then lift to the refined surface through the stencil table.
 */
export interface SkinBinding {
    /** 4 bone indices per vertex. */
    indices: Uint16Array | Uint32Array | Float32Array;
    /** 4 weights per vertex. */
    weights: Float32Array;
}
export declare function skinPositions(restPositions: Float32Array, binding: SkinBinding, 
/** 16 floats per bone, column-major (three.js Skeleton.boneMatrices). */
boneMatrices: Float32Array, 
/** 16 floats, column-major (three.js SkinnedMesh.bindMatrix.elements). */
bindMatrix: ArrayLike<number>, bindMatrixInverse: ArrayLike<number>, out: Float32Array): Float32Array;
//# sourceMappingURL=skinning.d.ts.map