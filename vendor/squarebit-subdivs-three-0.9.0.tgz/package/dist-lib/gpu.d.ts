export { GPUSubdivSurfaceMesh } from './three/gpu/GPUSubdivSurfaceMesh';
export type { GPUSubdivSurfaceMeshOptions } from './three/gpu/GPUSubdivSurfaceMesh';
//# sourceMappingURL=gpu.d.ts.map