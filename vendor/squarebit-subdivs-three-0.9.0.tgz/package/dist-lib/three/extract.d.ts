import type { BufferGeometry } from 'three';
import type { SubdivMesh } from '../core/types';
export interface ExtractedCage {
    mesh: SubdivMesh;
    /**
     * For each cage vertex, the index of one source vertex it was welded
     * from — used to fetch per-vertex source attributes (skin indices /
     * weights), which agree across welded duplicates.
     */
    cageToSource: Uint32Array;
    /** For each cage vertex, which input geometry `cageToSource` refers to. */
    cageToSourceGeometry: Uint16Array;
}
/**
 * Build one subdivision control cage from one or more three.js
 * BufferGeometries (a glTF node's primitives, or sibling skinned meshes
 * sharing a skeleton — the plugin's multi-section case).
 *
 * Renderer geometry duplicates vertices along UV/normal seams and splits
 * meshes at material borders; both would read as boundaries — infinitely
 * sharp creases — to the subdivision rules. Vertices are welded by
 * quantized position *across all inputs*, so section borders stay smooth,
 * while UVs stay face-varying per corner and each face records which
 * input it came from in `faceMaterialIndices` (input order = material slot,
 * emitted whenever more than one geometry is supplied).
 *
 * Faces are the geometries' triangles (n-gons are fine as cage input, but
 * triangulated sources are what three.js hands us). Degenerate triangles
 * that collapse under welding are dropped.
 */
export declare function fromGeometries(geometries: BufferGeometry[], weldTolerance?: number): ExtractedCage;
/** Single-geometry convenience wrapper. */
export declare function fromBufferGeometry(geometry: BufferGeometry, weldTolerance?: number): ExtractedCage;
//# sourceMappingURL=extract.d.ts.map