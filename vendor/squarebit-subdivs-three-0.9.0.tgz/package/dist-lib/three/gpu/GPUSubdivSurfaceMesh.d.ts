import { StorageBufferAttribute, type WebGPURenderer } from 'three/webgpu';
import type { Mesh } from 'three';
import { SubdivSurfaceMesh, type SubdivSurfaceMeshOptions } from '../SubdivSurfaceMesh';
export interface GPUSubdivSurfaceMeshOptions extends SubdivSurfaceMeshOptions {
    renderer: WebGPURenderer;
}
/**
 * GPU-evaluated subdivision surface — the web analogue of the plugin's
 * compute-shader path. The cage-sized CPU work (morph mix + skinning)
 * stays on the CPU; everything refined-mesh-sized moves into WGSL
 * compute kernels via three's TSL:
 *
 *   1. apply    — one thread per refined vertex: CSR stencil gather
 *   2. faceN    — one thread per quad: cross of diagonals (Newell)
 *   3. vertexN  — one thread per refined vertex: gather incident faces,
 *                 normalize
 *
 * The raster pass reads the computed buffers directly in the vertex stage
 * (node-material positionNode/normalNode routed through the UV-weld map),
 * so refined geometry never round-trips the CPU; the only per-frame
 * upload is the cage positions. All storage buffers are flat float/uint
 * arrays (itemSize 1) — WGSL array<vec3f> is 16-byte strided and does not
 * match three's packed attribute layout.
 *
 * Falls back to the CPU path when the refined mesh is not all-quads
 * (level 0).
 */
export declare class GPUSubdivSurfaceMesh extends SubdivSurfaceMesh {
    /** False when construction fell back to CPU evaluation (level-0 surface). */
    readonly gpuActive: boolean;
    private readonly renderer;
    private controlAttr;
    private kernels;
    /** Internal buffers exposed for numeric verification/readback. */
    readonly gpuBuffers: Record<string, StorageBufferAttribute>;
    constructor(source: Mesh | Mesh[], options: GPUSubdivSurfaceMeshOptions);
    private computeRestBounds;
    protected evaluateSurface(): void;
}
//# sourceMappingURL=GPUSubdivSurfaceMesh.d.ts.map