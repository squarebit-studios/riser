import { BufferGeometry } from 'three';
import type { SubdivMesh } from '../core/types';
/**
 * A BufferGeometry plus the mapping needed to re-feed it with animated
 * positions/normals each frame. `vertexSource[i]` gives the SubdivMesh
 * vertex behind render vertex i; it is null when the geometry references
 * the mesh's own arrays directly (no UV welding), in which case updating
 * `mesh.positions` in place and flagging needsUpdate is enough.
 */
export interface RenderMesh {
    geometry: BufferGeometry;
    vertexSource: Uint32Array | null;
}
/**
 * Convert a (refined) SubdivMesh into an indexed three.js geometry.
 * N-gons are fan-triangulated. When face-varying UVs are present, corners
 * are welded on exact (vertex, u, v) so UV seams split correctly while
 * smooth-shaded normals stay shared. Per-face material slots become
 * geometry groups.
 */
export declare function buildRenderMesh(mesh: SubdivMesh): RenderMesh;
/** Back-compat convenience: geometry only. */
export declare function toBufferGeometry(mesh: SubdivMesh): BufferGeometry;
/**
 * Copy animated positions + normals from the SubdivMesh into a welded
 * RenderMesh's attributes. No-op mapping-wise when the geometry shares the
 * mesh's arrays (vertexSource null) — then only needsUpdate is flagged.
 */
export declare function updateRenderMesh(render: RenderMesh, mesh: SubdivMesh, normals: Float32Array): void;
/**
 * Unique-edge line geometry for quad-wire display (a triangle wireframe
 * would show the fan diagonals). Indexed over the mesh's own positions
 * array, so in-place position updates animate the wireframe for free.
 */
export declare function toQuadWireframeGeometry(mesh: SubdivMesh): BufferGeometry;
//# sourceMappingURL=geometry.d.ts.map