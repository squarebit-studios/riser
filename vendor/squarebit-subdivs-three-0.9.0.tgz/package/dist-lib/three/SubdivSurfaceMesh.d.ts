import { Mesh, type Material } from 'three';
import type { SubdivMesh } from '../core/types';
import { type RefinedSurface } from '../core/stencils';
import { type QuadRecoveryOptions } from '../core/quadRecovery';
import { type RenderMesh } from './geometry';
export interface SubdivSurfaceMeshOptions {
    /** Subdivision levels (default 2). */
    levels?: number;
    /** Position-weld tolerance when extracting the cage (default 1e-5). */
    weldTolerance?: number;
    /**
     * Pair triangles back into quads before refinement (default true) —
     * triangulated sources like glTF get the authored Catmull-Clark look.
     * Pass `false` to refine the raw triangulation, or options to tune.
     */
    recoverQuads?: boolean | QuadRecoveryOptions;
    /** Material override; defaults to the source mesh materials. */
    material?: Material | Material[];
}
export declare class SubdivSurfaceMesh extends Mesh {
    /** Stage timings (ms) of the most recent construction, for diagnostics. */
    static lastBuildTimings: Record<string, number>;
    readonly surface: RefinedSurface;
    /** Welded control cage; positions update in place each frame (post-skin). */
    readonly cage: SubdivMesh;
    /** Per-frame CPU cost breakdown, in milliseconds. */
    readonly timings: {
        morphMs: number;
        skinMs: number;
        applyMs: number;
    };
    protected readonly renderMesh: RenderMesh;
    private readonly restPositions;
    protected readonly normalsBuffer: Float32Array;
    private readonly skinSource;
    private readonly binding;
    private readonly morphSets;
    private readonly morphedPositions;
    constructor(source: Mesh | Mesh[], options?: SubdivSurfaceMeshOptions);
    /** True when a source skeleton drives the cage. */
    get isSkinned(): boolean;
    update(): void;
    /** Cage-sized CPU work: mix morph influences, then skin — both O(cage). */
    protected updateCage(): void;
    /** Refined-mesh-sized work: stencil apply + normals + attribute refresh. */
    protected evaluateSurface(): void;
}
//# sourceMappingURL=SubdivSurfaceMesh.d.ts.map