import { a as e, c as t, d as n, f as r, h as i, i as a, l as o, m as s, n as c, o as l, p as u, r as d, s as f, t as p, u as m } from "./SubdivSurfaceMesh-CBPcePdj.js";
//#region src/core/types.ts
function h(e) {
	return {
		vertices: e.positions.length / 3,
		faces: e.faceVertexCounts.length,
		corners: e.faceVertexIndices.length
	};
}
//#endregion
//#region src/core/catmullClark.ts
function g(e) {
	let t = s(e);
	return {
		positions: u(t.rows, e.positions),
		faceVertexCounts: t.faceVertexCounts,
		faceVertexIndices: t.faceVertexIndices,
		uvs: t.uvs,
		faceMaterialIndices: t.faceMaterialIndices,
		creases: t.creases,
		corners: t.corners
	};
}
function _(e, t) {
	let n = e;
	for (let e = 0; e < t; e++) n = g(n);
	return n;
}
//#endregion
//#region src/core/shapes.ts
function v(e = 0) {
	let t = new Float32Array([
		-.5,
		-.5,
		-.5,
		.5,
		-.5,
		-.5,
		.5,
		.5,
		-.5,
		-.5,
		.5,
		-.5,
		-.5,
		-.5,
		.5,
		.5,
		-.5,
		.5,
		.5,
		.5,
		.5,
		-.5,
		.5,
		.5
	]), n = new Uint32Array([
		0,
		3,
		2,
		1,
		4,
		5,
		6,
		7,
		0,
		1,
		5,
		4,
		2,
		3,
		7,
		6,
		0,
		4,
		7,
		3,
		1,
		2,
		6,
		5
	]), r = (/* @__PURE__ */ new Uint32Array(6)).fill(4), i = /* @__PURE__ */ new Float32Array(48);
	for (let e = 0; e < 6; e++) i.set([
		0,
		0,
		1,
		0,
		1,
		1,
		0,
		1
	], e * 8);
	let a;
	if (e > 0) {
		let t = /* @__PURE__ */ new Set(), r = [];
		for (let e = 0; e < 6; e++) for (let i = 0; i < 4; i++) {
			let a = n[e * 4 + i], o = n[e * 4 + (i + 1) % 4], s = `${Math.min(a, o)}_${Math.max(a, o)}`;
			t.has(s) || (t.add(s), r.push(a, o));
		}
		a = {
			edges: new Uint32Array(r),
			sharpness: new Float32Array(r.length / 2).fill(e)
		};
	}
	return {
		positions: t,
		faceVertexCounts: r,
		faceVertexIndices: n,
		uvs: i,
		creases: a
	};
}
function y(e = 8, t = 3, n = .5, r = 1.2) {
	let i = [];
	for (let a = 0; a <= t; a++) {
		let o = -r / 2 + r * a / t;
		for (let t = 0; t < e; t++) {
			let r = t / e * Math.PI * 2;
			i.push(Math.cos(r) * n, o, Math.sin(r) * n);
		}
	}
	let a = [];
	for (let n = 0; n < t; n++) for (let t = 0; t < e; t++) {
		let r = (t + 1) % e, i = n * e, o = (n + 1) * e;
		a.push(i + t, i + r, o + r, o + t);
	}
	return {
		positions: new Float32Array(i),
		faceVertexCounts: new Uint32Array(t * e).fill(4),
		faceVertexIndices: new Uint32Array(a)
	};
}
function b(e = 8, t = 6, n = .7, r = .3) {
	let i = [];
	for (let a = 0; a < e; a++) {
		let o = a / e * Math.PI * 2;
		for (let e = 0; e < t; e++) {
			let a = e / t * Math.PI * 2, s = n + r * Math.cos(a);
			i.push(s * Math.cos(o), r * Math.sin(a), s * Math.sin(o));
		}
	}
	let a = [];
	for (let n = 0; n < e; n++) {
		let r = (n + 1) % e;
		for (let e = 0; e < t; e++) {
			let i = (e + 1) % t;
			a.push(n * t + e, r * t + e, r * t + i, n * t + i);
		}
	}
	return {
		positions: new Float32Array(i),
		faceVertexCounts: new Uint32Array(e * t).fill(4),
		faceVertexIndices: new Uint32Array(a)
	};
}
//#endregion
export { p as SubdivSurfaceMesh, u as applyRows, n as applyStencils, i as buildEdgeTopology, r as buildRefinedSurface, c as buildRenderMesh, m as computeVertexNormals, v as cube, l as fromBufferGeometry, f as fromGeometries, h as meshCounts, y as openCylinder, t as recoverQuads, s as refineLevel, o as skinPositions, g as subdivide, _ as subdivideLevels, d as toBufferGeometry, a as toQuadWireframeGeometry, b as torusCage, e as updateRenderMesh };

//# sourceMappingURL=index.js.map