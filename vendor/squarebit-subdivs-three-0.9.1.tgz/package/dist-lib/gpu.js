import { t as e } from "./SubdivSurfaceMesh-CBPcePdj.js";
import { MeshStandardNodeMaterial as t, StorageBufferAttribute as n } from "three/webgpu";
import { Fn as r, Loop as i, float as a, instanceIndex as o, storage as s, transformNormalToView as c, vec3 as l, vertexIndex as u } from "three/tsl";
//#region src/three/gpu/GPUSubdivSurfaceMesh.ts
var d = class extends e {
	gpuActive;
	renderer;
	controlAttr;
	kernels;
	gpuBuffers = {};
	constructor(e, t) {
		super(e, t);
		let d = this.surface.mesh;
		if (!d.faceVertexCounts.every((e) => e === 4)) {
			this.gpuActive = !1;
			return;
		}
		this.renderer = t.renderer;
		let p = d.positions.length / 3, m = d.faceVertexCounts.length, h = this.cage.positions.length / 3, g = this.surface.table, _ = s(new n(g.offsets, 1), "uint", p + 1), v = s(new n(g.indices, 1), "uint", g.indices.length), y = s(new n(g.weights, 1), "float", g.weights.length), b = s(new n(d.faceVertexIndices, 1), "uint", d.faceVertexIndices.length), x = new Uint32Array(p);
		for (let e = 0; e < d.faceVertexIndices.length; e++) x[d.faceVertexIndices[e]]++;
		let S = new Uint32Array(p + 1);
		for (let e = 0; e < p; e++) S[e + 1] = S[e] + x[e];
		let C = new Uint32Array(S[p]), w = S.slice(0, p);
		for (let e = 0; e < m; e++) for (let t = 0; t < 4; t++) {
			let n = d.faceVertexIndices[e * 4 + t];
			C[w[n]++] = e;
		}
		let T = s(new n(S, 1), "uint", p + 1), E = s(new n(C, 1), "uint", C.length), D = this.geometry.getAttribute("position").count, O;
		if (this.renderMesh.vertexSource) O = this.renderMesh.vertexSource;
		else {
			O = new Uint32Array(D);
			for (let e = 0; e < D; e++) O[e] = e;
		}
		let k = s(new n(O, 1), "uint", D).toReadOnly();
		this.controlAttr = new n(this.cage.positions.slice(), 1);
		let A = new n(p * 3, 1), j = new n(m * 3, 1), M = new n(p * 3, 1), N = s(this.controlAttr, "float", h * 3), P = s(A, "float", p * 3), F = s(j, "float", m * 3), I = s(M, "float", p * 3);
		this.gpuBuffers.control = this.controlAttr, this.gpuBuffers.positions = A, this.gpuBuffers.faceNormals = j, this.gpuBuffers.normals = M;
		let L = s(A, "float", p * 3).toReadOnly(), R = s(M, "float", p * 3).toReadOnly(), z = k.element(u).mul(3), B = l(L.element(z), L.element(z.add(1)), L.element(z.add(2))), V = c(l(R.element(z), R.element(z.add(1)), R.element(z.add(2)))), H = (Array.isArray(this.material) ? this.material : [this.material]).map((e) => {
			let t = f(e);
			return t.positionNode = B, t.normalNode = V, t;
		});
		this.material = Array.isArray(this.material) ? H : H[0];
		let U = r(() => {
			let e = o, t = a(0).toVar(), n = a(0).toVar(), r = a(0).toVar();
			i({
				start: _.element(e),
				end: _.element(e.add(1)),
				type: "uint"
			}, ({ i: e }) => {
				let i = v.element(e).mul(3), a = y.element(e);
				t.addAssign(N.element(i).mul(a)), n.addAssign(N.element(i.add(1)).mul(a)), r.addAssign(N.element(i.add(2)).mul(a));
			});
			let s = e.mul(3);
			P.element(s).assign(t), P.element(s.add(1)).assign(n), P.element(s.add(2)).assign(r);
		})().compute(p), W = (e) => {
			let t = e.mul(3);
			return l(P.element(t), P.element(t.add(1)), P.element(t.add(2)));
		}, G = r(() => {
			let e = o, t = e.mul(4), n = W(b.element(t)), r = W(b.element(t.add(1))), i = W(b.element(t.add(2))), a = W(b.element(t.add(3))), s = i.sub(n).cross(a.sub(r)), c = e.mul(3);
			F.element(c).assign(s.x), F.element(c.add(1)).assign(s.y), F.element(c.add(2)).assign(s.z);
		})().compute(m), K = r(() => {
			let e = o, t = l(0).toVar();
			i({
				start: T.element(e),
				end: T.element(e.add(1)),
				type: "uint"
			}, ({ i: e }) => {
				let n = E.element(e).mul(3);
				t.addAssign(l(F.element(n), F.element(n.add(1)), F.element(n.add(2))));
			});
			let n = t.normalize(), r = e.mul(3);
			I.element(r).assign(n.x), I.element(r.add(1)).assign(n.y), I.element(r.add(2)).assign(n.z);
		})().compute(p);
		this.kernels = [
			U,
			G,
			K
		], this.geometry.boundingSphere = null, this.computeRestBounds(), this.gpuActive = !0;
	}
	computeRestBounds() {
		let e = this.surface.mesh, t = 0, n = 0, r = 0, i = e.positions.length / 3;
		for (let a = 0; a < i; a++) t += e.positions[a * 3], n += e.positions[a * 3 + 1], r += e.positions[a * 3 + 2];
		t /= i, n /= i, r /= i;
		let a = 0;
		for (let o = 0; o < i; o++) {
			let i = e.positions[o * 3] - t, s = e.positions[o * 3 + 1] - n, c = e.positions[o * 3 + 2] - r;
			a = Math.max(a, i * i + s * s + c * c);
		}
		this.geometry.computeBoundingSphere(), this.geometry.boundingSphere && (this.geometry.boundingSphere.center.set(t, n, r), this.geometry.boundingSphere.radius = Math.sqrt(a)), this.frustumCulled = !1;
	}
	evaluateSurface() {
		if (!this.gpuActive) {
			super.evaluateSurface();
			return;
		}
		let e = performance.now();
		this.controlAttr.array.set(this.cage.positions), this.controlAttr.needsUpdate = !0;
		for (let e of this.kernels) this.renderer.compute(e);
		this.timings.applyMs = performance.now() - e;
	}
};
function f(e) {
	let n = e, r = new t();
	return n.color && r.color.copy(n.color), r.map = n.map ?? null, typeof n.roughness == "number" && (r.roughness = n.roughness), typeof n.metalness == "number" && (r.metalness = n.metalness), r.roughnessMap = n.roughnessMap ?? null, r.metalnessMap = n.metalnessMap ?? null, r.aoMap = n.aoMap ?? null, n.emissive && r.emissive.copy(n.emissive), r.emissiveMap = n.emissiveMap ?? null, r.side = n.side, r.transparent = n.transparent, r.opacity = n.opacity, r.alphaMap = n.alphaMap ?? null, typeof n.alphaTest == "number" && (r.alphaTest = n.alphaTest), r;
}
//#endregion
export { d as GPUSubdivSurfaceMesh };

//# sourceMappingURL=gpu.js.map