# Squarebit Subdivs — three.js (web version)

Catmull-Clark subdivision surfaces in the browser, shipped alongside the Unreal Engine plugin. Same product idea — take a coarse control cage and render its subdivision-surface limit — targeting three.js instead of UE.

## Status: v0.9 — packaged library

- ✅ CPU Catmull-Clark kernel (TypeScript, typed arrays, no three.js dependency)
- ✅ Semi-sharp edge creases + vertex corners (uniform per-level decay)
- ✅ Boundary rules (open meshes treated as infinitely sharp, matching the plugin)
- ✅ Face-varying UVs (bilinear interpolation for now)
- ✅ **Stencil tables** (`buildRefinedSurface` / `applyStencils`): refinement rules are
  emitted as sparse weight matrices and composed across levels, so animated control
  points re-evaluate with one sparse matrix-vector product per frame — the plugin's
  Far::StencilTable architecture. Direct subdivision (`subdivide`) applies the same
  matrices, so the two paths cannot diverge.
- ✅ three.js integration: `buildRenderMesh` / `updateRenderMesh` for per-frame
  updates (welded UV seams, smooth normals) + indexed quad wireframe helper
- ✅ **Skinned meshes** (`SubdivSurfaceMesh`): drop-in three.js mesh that renders
  the subdivision surface of any Mesh/SkinnedMesh. Extracts a welded control cage
  from renderer geometry (UV/normal seams re-joined, UVs kept face-varying), CPU-skins
  the cage from the source's skeleton (exact three.js skinning math), and lifts
  through the stencil table per frame — the plugin's skeletal-component flow
- ✅ **Quad recovery** (`recoverQuads`, on by default in `SubdivSurfaceMesh`):
  pairs coplanar, well-shaped triangles back into quads before refinement so
  triangulated sources (glTF) get the authored Catmull-Clark look — greedy
  best-score merging with planarity/corner-angle/UV-seam guards; positions and
  vertex indices untouched so creases and skin bindings pass through
- ✅ **glTF loading**: drag-and-drop a .glb/.gltf (or `?model=<url>`, or the
  Load button) — the demo wraps the asset's meshes in a `SubdivSurfaceMesh`
  (weld → quad recovery → stencils), keeps the asset's own materials, plays its
  first animation clip through an `AnimationMixer`, and auto-frames the camera
- ✅ **Multi-section characters** (the plugin's `FSection[]` analogue):
  `SubdivSurfaceMesh` accepts an array of meshes (glTF primitives / siblings on
  one skeleton) and welds them into a *single* cage so section borders subdivide
  smoothly instead of reading as boundary creases; per-face material slots
  survive refinement and become geometry groups (one draw range per material).
  Verified against Khronos BrainStem (59 sections, animated)
- ✅ **Morph targets**: blendshape deltas mix into the cage rest pose, then
  skinning deforms the morphed cage, then stencils lift to the surface — the
  plugin's (and three.js's) deformation order. Handles relative (glTF) and
  absolute (legacy three) morph attributes; driven per frame by the source
  mesh's `morphTargetInfluences`, so AnimationMixer weight tracks just work.
  Loaded models follow their source node's world transform
- ✅ **GPU compute evaluation** (`GPUSubdivSurfaceMesh`, WebGPU): the plugin's
  compute-shader path. Cage-sized work (morph mix + skinning) stays on the CPU;
  stencil apply, quad face normals, and vertex-normal gather run as WGSL
  kernels, and the raster pass reads the computed buffers directly in the
  vertex stage (node-material positionNode/normalNode through the UV-weld
  map) — refined geometry never round-trips the CPU. Numerically exact vs the
  CPU path (verified by device readback, max err ~1e-7). The demo uses it
  automatically when WebGPU is available (`?gpu=0` forces WebGL + CPU)
- ✅ Interactive demo viewer (Vite) with level slider, crease control, cage display,
  an animated twist/bounce cage deformer, and a bone-driven skinned cylinder
- ✅ Vitest suite: kernel math, stencil↔subdivision parity (levels, creases,
  boundaries, deformed cages, affinity of every stencil row), CPU skinning vs
  posed three.js skeletons, and cage extraction on real three.js geometry

## Quick start

```bash
cd web
npm install
npm run dev        # demo viewer at http://localhost:5173
npm test           # kernel unit tests
npm run bench      # per-frame pipeline benchmarks
npm run build      # typecheck + demo bundle in dist/
npm run build:lib  # library bundle + .d.ts in dist-lib/ (npm pack-ready)
```

## Using the library

The package builds to `dist-lib/` with `three` as a peer dependency
(`npm run build:lib`; `"private": true` guards against accidental publish —
remove it when we're ready to ship to a registry).

```ts
import { SubdivSurfaceMesh } from '@squarebit/subdivs-three';

// Wrap any Mesh / SkinnedMesh (or an array of glTF primitives on one skeleton):
const subdiv = new SubdivSurfaceMesh(gltf.scene.getObjectByName('Body'), { levels: 2 });
sourceMesh.visible = false;   // keep the source for its skeleton, hide its geometry
scene.add(subdiv);

// Per frame, after advancing the AnimationMixer:
subdiv.update();              // morphs -> skinning -> stencil lift -> normals
```

WebGPU evaluation lives behind a separate entry so WebGL-only apps never
pull in `three/webgpu`:

```ts
import { GPUSubdivSurfaceMesh } from '@squarebit/subdivs-three/gpu';

const subdiv = new GPUSubdivSurfaceMesh(source, { levels: 2, renderer }); // WebGPURenderer
```

The subdivision kernel itself (`subdivideLevels`, `buildRefinedSurface`,
`applyStencils`, `recoverQuads`, …) has no three.js dependency and is
exported from the main entry for headless / worker use.

## Performance (CPU path, Node 24 / x64)

Synthetic character-scale cage (768-quad torus), per frame:

| refined size | applyStencils | normals | frame total |
|---|---|---|---|
| level 3, ~49k faces | 1.8 ms | 0.8 ms | 2.6 ms |
| level 4, ~197k faces | 7.9 ms | 3.3 ms | 11.3 ms |

Table build (`buildRefinedSurface`, same cage, level 3): **31 ms** — scatter-gather
SpGEMM composition and row-sequential refinement, no Maps in the hot path.

Normals use an all-quad fast path (a quad's Newell normal is the cross
product of its diagonals).

With the WebGPU path, the per-frame CPU cost collapses to cage skinning +
kernel submission: Khronos BrainStem (32.5k-vert cage → 139k-vert surface)
runs at ~1.2 ms/frame CPU-side vs ~15–20 ms on the CPU path, and the
refined geometry never leaves the GPU.

## Layout

```
web/
├── src/core/    # Subdivision kernel — pure TypeScript, no rendering deps
│   ├── types.ts         # SubdivMesh / crease / corner types
│   ├── topology.ts      # Edge connectivity + sharpness resolution per level
│   ├── refine.ts        # Refinement rules as sparse weight matrices (single source of truth)
│   ├── catmullClark.ts  # subdivide/subdivideLevels — applies one level's matrix to positions
│   ├── stencils.ts      # Cross-level matrix composition -> per-frame applyStencils
│   ├── skinning.ts      # CPU linear-blend skinning over flat arrays
│   ├── quadRecovery.ts  # Tris -> quads pairing for triangulated sources
│   └── normals.ts       # Smooth vertex normals (Newell, area-weighted)
├── src/three/   # three.js adapters
│   ├── geometry.ts          # BufferGeometry build/update, quad wireframe
│   ├── extract.ts           # BufferGeometry -> welded control cage
│   ├── SubdivSurfaceMesh.ts # Drop-in subdivided Mesh/SkinnedMesh wrapper (CPU)
│   └── gpu/GPUSubdivSurfaceMesh.ts # WebGPU compute evaluation subclass
├── src/demo/    # Viewer app (Vite entry)
└── src/index.ts # Library entry point
```

The core/three split mirrors the plugin's OSD-topology vs render-proxy separation, so the kernel can later be swapped for (or validated against) an OpenSubdiv WASM build without touching callers.

## Roadmap

- [x] Stencil-table precompute: refine topology once, re-apply to animated control points per frame (the plugin's core trick)
- [ ] Chaikin crease decay + OSD-exact semi-sharp vertex blending (current: uniform decay, linear blend)
- [ ] Smooth face-varying UV rules (current: FVAR_LINEAR_ALL)
- [x] GPU evaluation (WebGPU compute) for the per-frame stencil apply + normals
- [ ] Normal maps on the GPU path (dropped in node-material conversion for now)
- [ ] Stencil-based smooth normals (analytic limit tangents rather than per-frame Newell recompute)
- [x] Faster stencil-table build (230 ms → 31 ms on the level-3 bench: SpGEMM
  compose + row-sequential refine over dense scratch, no Maps)
- [x] npm packaging: `dist-lib/` ES build + declarations, `.`/`./gpu` export
  map, three as peer dependency, verified via pack + consumer smoke test
- [x] Subdivide skinned meshes, plug into three.js skeleton animation (`SubdivSurfaceMesh`
  works with any SkinnedMesh, including GLTFLoader output)
- [x] Quad recovery on triangulated input (pair triangles back into quads pre-refinement)
- [x] Demo: glTF drag-and-drop / URL loading + AnimationMixer playback
  (verified against Khronos RiggedSimple)
- [x] Multi-primitive / multi-material glTF nodes welded into one cage with
  per-section materials (verified against Khronos BrainStem)
- [x] Morph targets (blendshapes) applied to the cage pre-stencil, like the plugin
  (verified against Khronos AnimatedMorphCube)
- [ ] Adaptive level / distance LOD
- [ ] Validate against OpenSubdiv (WASM build or golden data exported from the UE plugin)
