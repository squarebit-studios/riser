import type { SubdivMesh } from './types';
import type { EdgeTopology } from './topology';
/**
 * Face-varying (UV) refinement, built the way the plugin builds it.
 *
 * WHY THIS EXISTS. Positions are smoothed by Catmull-Clark; UVs used to be
 * split bilinearly per original face (OpenSubdiv's FVAR_LINEAR_ALL). Those two
 * do not agree. A refined vertex slides toward the limit surface, its UV does
 * not slide with it, and the texture drifts by a fraction of a cage face all
 * over the model. On a character that reads as stretching, and it is worst
 * exactly where the cage is irregular, which is the face.
 *
 * THE FIX, which is what OpenSubdiv does and what the Unreal plugin has always
 * asked it for: refine the UVs as their own channel, with the same subdivision
 * rules the positions get. Inside a UV island the face-varying topology is the
 * same topology the positions have, so the two get the SAME weights and the UV
 * field follows the surface exactly. Island boundaries are the only place the
 * two differ, and there the boundary is kept linear so a seam cannot slide and
 * pull the two sides of a texture apart (OSD's FVAR_LINEAR_BOUNDARIES, which
 * is the plugin's default `PinBoundaries` and matches Maya's "Preserve Map
 * Borders: Internal").
 *
 * HOW. A UV channel is just another mesh: its vertices are the face-varying
 * VALUES, its faces are the same faces, and its face-vertex indices are the
 * per-corner value ids. Refining it is therefore the ordinary refinement,
 * applied to (u, v, 0) instead of (x, y, z) - which is what makes "the same
 * weights as the positions" true by construction rather than by coincidence.
 */
/** The face-varying channel a per-corner UV array implies. */
export interface FvarChannel {
    /**
     * A cage whose vertices are the UV values, ready to be refined. Positions
     * are (u, v, 0), three floats per value, so it goes through `applyRows`
     * unchanged.
     */
    cage: SubdivMesh;
    /** Value id per corner, aligned with the mesh's `faceVertexIndices`. */
    cornerValues: Uint32Array;
}
/**
 * Build the UV channel of a mesh.
 *
 * Corners are welded on (vertex, u, v). Two corners meeting at one vertex with
 * the same UV are one face-varying value; different UVs are different values.
 * That is exactly the seam structure a DCC authors and that `primvars:st:indices`
 * records in a USD file, recovered from the flattened per-corner array the
 * SubdivMesh carries.
 *
 * `topo` is the mesh's own edge topology, which the caller has already built.
 * It is what tells a seam from an island interior without a second pass over
 * the edges: an edge is a UV boundary when it is a mesh boundary, or when the
 * two faces sharing it disagree about the UVs at its ends.
 */
export declare function fvarChannelFor(mesh: SubdivMesh, topo: EdgeTopology): FvarChannel | null;
//# sourceMappingURL=faceVarying.d.ts.map