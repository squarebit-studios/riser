import type { SubdivMesh } from './types';
/**
 * One level of Catmull-Clark subdivision with semi-sharp crease support.
 *
 * Rules follow the classic Catmull-Clark / DeRose et al. formulation that
 * OpenSubdiv implements, with two documented simplifications for now:
 *  - crease decay is uniform (sharpness - 1 per level) rather than Chaikin
 *
 * Face-varying UVs are refined with the same rules as the positions, with UV
 * island boundaries kept linear (OSD FVAR_LINEAR_BOUNDARIES); see
 * faceVarying.ts and `SubdivMesh.uvInterpolation`.
 *
 * The rules themselves live in `refineLevel` as a sparse weight matrix
 * (see refine.ts); this entry point just applies that matrix to the
 * mesh's positions. Stencil tables (stencils.ts) compose the same
 * matrices across levels, so the two paths cannot diverge.
 *
 * Child vertex layout: [parent vertex points | face points | edge points],
 * so parent vertex v keeps index v, face f's point is V + f, and edge e's
 * point is V + F + e.
 */
export declare function subdivide(mesh: SubdivMesh): SubdivMesh;
/** Apply `levels` rounds of subdivision (0 returns the input unchanged). */
export declare function subdivideLevels(mesh: SubdivMesh, levels: number): SubdivMesh;
//# sourceMappingURL=catmullClark.d.ts.map