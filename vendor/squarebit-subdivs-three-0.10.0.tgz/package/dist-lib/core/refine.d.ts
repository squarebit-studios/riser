import type { CornerSet, CreaseSet, SubdivMesh, UvInterpolation } from './types';
/**
 * Sparse row-major matrix (CSR): row i holds entries
 * [offsets[i], offsets[i+1]) of (indices, weights).
 *
 * Because every Catmull-Clark rule is a position-independent affine
 * combination of parent vertices, one level of refinement is exactly a
 * sparse matrix: childPositions = rows * parentPositions. This is the
 * same observation OpenSubdiv's stencil tables are built on, and it is
 * what lets the plugin refine topology once and re-apply it to animated
 * control points every frame.
 */
export interface SparseRows {
    offsets: Uint32Array;
    indices: Uint32Array;
    weights: Float64Array;
    rowCount: number;
    columnCount: number;
}
/** One level of uniform refinement: the weight matrix plus the child topology. */
export interface LevelRefinement {
    rows: SparseRows;
    faceVertexCounts: Uint32Array;
    faceVertexIndices: Uint32Array;
    uvs?: Float32Array;
    faceMaterialIndices?: Uint32Array;
    creases?: CreaseSet;
    corners?: CornerSet;
    uvInterpolation?: UvInterpolation;
}
/**
 * Compute one level of Catmull-Clark refinement symbolically.
 *
 * Child vertex layout matches `subdivide`: [parent vertex points (V) |
 * face points (F) | edge points (E)]. Row i of the returned matrix gives
 * child vertex i as an affine combination of parent vertices.
 */
export declare function refineLevel(mesh: SubdivMesh): LevelRefinement;
/** Apply a sparse weight matrix to xyz positions: out = rows * src. */
export declare function applyRows(rows: {
    offsets: Uint32Array;
    indices: Uint32Array;
    weights: Float64Array | Float32Array;
    rowCount: number;
}, src: Float32Array, out?: Float32Array): Float32Array;
//# sourceMappingURL=refine.d.ts.map