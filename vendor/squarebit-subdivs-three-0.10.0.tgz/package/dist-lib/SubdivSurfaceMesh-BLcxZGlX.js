import { BufferAttribute as e, BufferGeometry as t, Mesh as n } from "three";
//#region src/core/topology.ts
function r(e) {
	let t = e.positions.length / 3, n = e.faceVertexCounts.length, r = e.faceVertexIndices.length, i = new Uint32Array(n + 1);
	for (let t = 0; t < n; t++) i[t + 1] = i[t] + e.faceVertexCounts[t];
	let a = /* @__PURE__ */ new Map(), o = new Uint32Array(r), s = 0;
	for (let r = 0; r < n; r++) {
		let n = i[r], c = e.faceVertexCounts[r];
		for (let r = 0; r < c; r++) {
			let i = e.faceVertexIndices[n + r], l = e.faceVertexIndices[n + (r + 1) % c], u = Math.min(i, l), d = Math.max(i, l), f = u * t + d, p = a.get(f);
			p === void 0 && (p = s++, a.set(f, p)), o[n + r] = p;
		}
	}
	let c = new Uint32Array(s * 2), l = new Int32Array(s * 2).fill(-1), u = new Uint8Array(s);
	for (let t = 0; t < n; t++) {
		let n = i[t], r = e.faceVertexCounts[t];
		for (let i = 0; i < r; i++) {
			let a = e.faceVertexIndices[n + i], s = e.faceVertexIndices[n + (i + 1) % r], d = o[n + i];
			c[d * 2] = Math.min(a, s), c[d * 2 + 1] = Math.max(a, s);
			let f = u[d];
			f < 2 && (l[d * 2 + f] = t), f < 255 && (u[d] = f + 1);
		}
	}
	let d = new Float32Array(s);
	if (e.creases) {
		let n = e.creases.edges;
		for (let r = 0; r < n.length / 2; r++) {
			let i = n[r * 2], o = n[r * 2 + 1], s = Math.min(i, o), c = Math.max(i, o), l = a.get(s * t + c);
			l !== void 0 && (d[l] = Math.max(d[l], e.creases.sharpness[r]));
		}
	}
	for (let e = 0; e < s; e++) u[e] !== 2 && (d[e] = Infinity);
	return {
		edgeCount: s,
		edgeVertices: c,
		edgeFaces: l,
		edgeFaceCounts: u,
		cornerEdges: o,
		faceOffsets: i,
		edgeSharpness: d
	};
}
//#endregion
//#region src/core/faceVarying.ts
function i(e, t) {
	let n = e.uvs, r = e.faceVertexIndices.length;
	if (!n || n.length !== r * 2) return null;
	let i = e.positions.length / 3, a = new Uint32Array(i + 1);
	for (let t = 0; t < r; t++) a[e.faceVertexIndices[t] + 1]++;
	for (let e = 0; e < i; e++) a[e + 1] += a[e];
	let o = new Float32Array(r), s = new Float32Array(r), c = new Uint32Array(r), l = new Uint32Array(i), u = new Uint32Array(r), d = new Float32Array(r * 3), f = 0;
	for (let t = 0; t < r; t++) {
		let r = e.faceVertexIndices[t], i = n[t * 2], p = n[t * 2 + 1], m = a[r], h = l[r], g = -1;
		for (let e = 0; e < h; e++) if (o[m + e] === i && s[m + e] === p) {
			g = c[m + e];
			break;
		}
		g < 0 && (g = f++, o[m + h] = i, s[m + h] = p, c[m + h] = g, l[r] = h + 1, d[g * 3] = i, d[g * 3 + 1] = p), u[t] = g;
	}
	let p = new Uint8Array(f), m = new Int32Array(t.edgeCount).fill(-1), h = new Int32Array(t.edgeCount).fill(-1), g = new Uint8Array(t.edgeCount), _ = e.faceVertexCounts;
	for (let n = 0; n < _.length; n++) {
		let r = t.faceOffsets[n], i = _[n];
		for (let n = 0; n < i; n++) {
			let a = r + n, o = r + (n + 1) % i, s = t.cornerEdges[a];
			if (t.edgeFaceCounts[s] !== 2) {
				g[s] = 1;
				continue;
			}
			let c = e.faceVertexIndices[a] === t.edgeVertices[s * 2], l = c ? u[a] : u[o], d = c ? u[o] : u[a];
			m[s] < 0 ? (m[s] = l, h[s] = d) : (m[s] !== l || h[s] !== d) && (g[s] = 1);
		}
	}
	let v = [], y = [], b = new Uint8Array(t.edgeCount), x = new Float32Array(i);
	if (e.corners) for (let t = 0; t < e.corners.vertices.length; t++) {
		let n = e.corners.vertices[t];
		x[n] = Math.max(x[n], e.corners.sharpness[t]);
	}
	for (let n = 0; n < _.length; n++) {
		let r = t.faceOffsets[n], i = _[n];
		for (let n = 0; n < i; n++) {
			let a = r + n, o = r + (n + 1) % i, s = t.cornerEdges[a];
			g[s] ? (p[u[a]] = 1, p[u[o]] = 1) : t.edgeSharpness[s] > 0 && !b[s] && (b[s] = 1, v.push(u[a], u[o]), y.push(t.edgeSharpness[s])), x[e.faceVertexIndices[a]] > 0 && (p[u[a]] = 1);
		}
	}
	let S = [];
	for (let e = 0; e < f; e++) p[e] && S.push(e);
	let C = {
		positions: d.slice(0, f * 3),
		faceVertexCounts: _,
		faceVertexIndices: u
	};
	return y.length && (C.creases = {
		edges: new Uint32Array(v),
		sharpness: new Float32Array(y)
	}), S.length && (C.corners = {
		vertices: new Uint32Array(S),
		sharpness: new Float32Array(S.length).fill(Infinity)
	}), {
		cage: C,
		cornerValues: u
	};
}
//#endregion
//#region src/core/refine.ts
var a = class {
	offsets;
	indices;
	weights;
	n = 0;
	row = -1;
	scratch;
	mark;
	touched;
	touchedCount = 0;
	constructor(e, t, n) {
		this.offsets = new Uint32Array(e + 1), this.indices = new Uint32Array(n), this.weights = new Float64Array(n), this.scratch = new Float64Array(t), this.mark = new Int32Array(t).fill(-1), this.touched = new Uint32Array(t);
	}
	add(e, t) {
		t !== 0 && (this.mark[e] !== this.row && (this.mark[e] = this.row, this.scratch[e] = 0, this.touched[this.touchedCount++] = e), this.scratch[e] += t);
	}
	beginRow(e) {
		this.row = e, this.touchedCount = 0;
	}
	endRow() {
		if (this.n + this.touchedCount > this.indices.length) {
			let e = Math.max(this.indices.length * 2, this.n + this.touchedCount), t = new Uint32Array(e);
			t.set(this.indices.subarray(0, this.n)), this.indices = t;
			let n = new Float64Array(e);
			n.set(this.weights.subarray(0, this.n)), this.weights = n;
		}
		for (let e = 0; e < this.touchedCount; e++) {
			let t = this.touched[e];
			this.indices[this.n] = t, this.weights[this.n] = this.scratch[t], this.n++;
		}
		this.offsets[this.row + 1] = this.n;
	}
	finish(e, t) {
		return {
			offsets: this.offsets,
			indices: this.indices.slice(0, this.n),
			weights: this.weights.slice(0, this.n),
			rowCount: e,
			columnCount: t
		};
	}
};
function o(e) {
	let t = e.positions.length / 3, n = e.faceVertexCounts.length, c = r(e), l = c.edgeCount, u = new Uint32Array(t), d = new Uint32Array(t), f = new Uint32Array(t), p = new Float32Array(t), m = new Int32Array(t * 2).fill(-1);
	for (let e = 0; e < l; e++) {
		let t = c.edgeVertices[e * 2], n = c.edgeVertices[e * 2 + 1], r = c.edgeSharpness[e];
		for (let [e, i] of [[t, n], [n, t]]) u[e]++, r > 0 && (f[e] < 2 && (m[e * 2 + f[e]] = i), f[e]++, p[e] += Math.min(r, 1));
	}
	let h = 0;
	for (let t = 0; t < n; t++) {
		let n = e.faceVertexCounts[t];
		for (let t = 0; t < n; t++) d[e.faceVertexIndices[h + t]]++;
		h += n;
	}
	let g = new Uint32Array(t + 1);
	for (let e = 0; e < t; e++) g[e + 1] = g[e] + u[e];
	let _ = new Uint32Array(g[t]);
	{
		let e = g.slice(0, t);
		for (let t = 0; t < l; t++) {
			let n = c.edgeVertices[t * 2], r = c.edgeVertices[t * 2 + 1];
			_[e[n]++] = r, _[e[r]++] = n;
		}
	}
	let v = new Uint32Array(t + 1);
	for (let e = 0; e < t; e++) v[e + 1] = v[e] + d[e];
	let y = new Uint32Array(v[t]);
	{
		let r = v.slice(0, t);
		h = 0;
		for (let t = 0; t < n; t++) {
			let n = e.faceVertexCounts[t];
			for (let i = 0; i < n; i++) y[r[e.faceVertexIndices[h + i]]++] = t;
			h += n;
		}
	}
	let b = new Float32Array(t);
	if (e.corners) for (let t = 0; t < e.corners.vertices.length; t++) {
		let n = e.corners.vertices[t];
		b[n] = Math.max(b[n], e.corners.sharpness[t]);
	}
	let x = e.faceVertexIndices, S = new a(t + n + l, t, (t + n + l) * 8);
	for (let n = 0; n < t; n++) {
		S.beginRow(n);
		let t = u[n], r = f[n], i = Math.min(b[n], 1), a = 0;
		r === 2 ? a = Math.min(p[n] / 2, 1) : r > 2 && (a = Math.min(p[n] / r, 1));
		let o = (1 - a) * (1 - i), s = t >= 3 && d[n] > 0, l = i;
		if (r === 2) {
			let e = a * (1 - i);
			l += 6 / 8 * e, S.add(m[n * 2], e / 8), S.add(m[n * 2 + 1], e / 8);
		} else r > 2 && (l += a * (1 - i));
		if (s) {
			if (l += o * ((t - 2) / t), o !== 0) {
				let r = o / (t * t);
				for (let e = g[n]; e < g[n + 1]; e++) S.add(_[e], r);
				let i = o / (t * d[n]);
				for (let t = v[n]; t < v[n + 1]; t++) {
					let n = y[t], r = c.faceOffsets[n], a = e.faceVertexCounts[n], o = i / a;
					for (let e = 0; e < a; e++) S.add(x[r + e], o);
				}
			}
		} else l += o;
		S.add(n, l), S.endRow();
	}
	for (let r = 0; r < n; r++) {
		S.beginRow(t + r);
		let n = c.faceOffsets[r], i = e.faceVertexCounts[r];
		for (let e = 0; e < i; e++) S.add(x[n + e], 1 / i);
		S.endRow();
	}
	for (let r = 0; r < l; r++) {
		S.beginRow(t + n + r);
		let i = c.edgeVertices[r * 2], a = c.edgeVertices[r * 2 + 1], o = Math.min(c.edgeSharpness[r], 1);
		if (o < 1 && c.edgeFaceCounts[r] === 2) {
			let t = .25 * (1 - o) + .5 * o;
			S.add(i, t), S.add(a, t);
			let n = .25 * (1 - o);
			for (let t of [c.edgeFaces[r * 2], c.edgeFaces[r * 2 + 1]]) {
				let r = c.faceOffsets[t], i = e.faceVertexCounts[t], a = n / i;
				for (let e = 0; e < i; e++) S.add(x[r + e], a);
			}
		} else S.add(i, .5), S.add(a, .5);
		S.endRow();
	}
	let C = S.finish(t + n + l, t), w = e.faceVertexIndices.length, T = new Uint32Array(w).fill(4), E = new Uint32Array(w * 4), D = e.faceMaterialIndices ? new Uint32Array(w) : void 0, O = !!e.uvs && e.uvs.length === w * 2, k = (e.uvInterpolation ?? "smooth") === "smooth", A = O && k ? i(e, c) : null, j = O ? new Float32Array(w * 4 * 2) : void 0, M = O && !A, N = 0;
	for (let r = 0; r < n; r++) {
		let i = c.faceOffsets[r], a = e.faceVertexCounts[r], o = 0, s = 0;
		if (M && e.uvs) {
			for (let t = 0; t < a; t++) o += e.uvs[(i + t) * 2], s += e.uvs[(i + t) * 2 + 1];
			o /= a, s /= a;
		}
		for (let l = 0; l < a; l++) {
			let u = e.faceVertexIndices[i + l], d = c.cornerEdges[i + l], f = c.cornerEdges[i + (l - 1 + a) % a];
			D && e.faceMaterialIndices && (D[N] = e.faceMaterialIndices[r]);
			let p = N * 4;
			if (E[p] = u, E[p + 1] = t + n + d, E[p + 2] = t + r, E[p + 3] = t + n + f, M && e.uvs && j) {
				let t = e.uvs[(i + l) * 2], n = e.uvs[(i + l) * 2 + 1], r = e.uvs[(i + (l + 1) % a) * 2], c = e.uvs[(i + (l + 1) % a) * 2 + 1], u = e.uvs[(i + (l - 1 + a) % a) * 2], d = e.uvs[(i + (l - 1 + a) % a) * 2 + 1], f = p * 2;
				j[f] = t, j[f + 1] = n, j[f + 2] = (t + r) * .5, j[f + 3] = (n + c) * .5, j[f + 4] = o, j[f + 5] = s, j[f + 6] = (t + u) * .5, j[f + 7] = (n + d) * .5;
			}
			N++;
		}
	}
	if (A && j) {
		let e = o(A.cage), t = s(e.rows, A.cage.positions);
		if (e.faceVertexIndices.length === j.length / 2) for (let n = 0; n < e.faceVertexIndices.length; n++) {
			let r = e.faceVertexIndices[n] * 3;
			j[n * 2] = t[r], j[n * 2 + 1] = t[r + 1];
		}
	}
	let P = [], F = [];
	for (let e = 0; e < l; e++) {
		let r = c.edgeSharpness[e];
		if (r <= 1) continue;
		let i = isFinite(r) ? r - 1 : Infinity, a = t + n + e;
		P.push(c.edgeVertices[e * 2], a, c.edgeVertices[e * 2 + 1], a), F.push(i, i);
	}
	let I;
	if (e.corners) {
		let t = [], n = [];
		for (let r = 0; r < e.corners.vertices.length; r++) {
			let i = isFinite(e.corners.sharpness[r]) ? e.corners.sharpness[r] - 1 : Infinity;
			i > 0 && (t.push(e.corners.vertices[r]), n.push(i));
		}
		t.length && (I = {
			vertices: new Uint32Array(t),
			sharpness: new Float32Array(n)
		});
	}
	return {
		rows: C,
		faceVertexCounts: T,
		faceVertexIndices: E,
		uvs: j,
		uvInterpolation: e.uvInterpolation,
		faceMaterialIndices: D,
		creases: P.length ? {
			edges: new Uint32Array(P),
			sharpness: new Float32Array(F)
		} : void 0,
		corners: I
	};
}
function s(e, t, n) {
	let { offsets: r, indices: i, weights: a, rowCount: o } = e, s = n ?? new Float32Array(o * 3), c = r[0];
	for (let e = 0; e < o; e++) {
		let n = r[e + 1], o = 0, l = 0, u = 0;
		for (; c < n; c++) {
			let e = i[c] * 3, n = a[c];
			o += t[e] * n, l += t[e + 1] * n, u += t[e + 2] * n;
		}
		s[e * 3] = o, s[e * 3 + 1] = l, s[e * 3 + 2] = u;
	}
	return s;
}
//#endregion
//#region src/core/stencils.ts
function c(e) {
	let t = new Uint32Array(e + 1), n = new Uint32Array(e), r = new Float32Array(e).fill(1);
	for (let r = 0; r < e; r++) t[r + 1] = r + 1, n[r] = r;
	return {
		offsets: t,
		indices: n,
		weights: r,
		rowCount: e,
		controlVertexCount: e
	};
}
function l(e, t) {
	let n = e.rowCount, r = t.controlVertexCount, i = new Float64Array(r), a = new Int32Array(r).fill(-1), o = new Uint32Array(r), s = new Uint32Array(n + 1), c = Math.max(1024, e.offsets[n] * 4), l = new Uint32Array(c), u = new Float32Array(c), d = 0;
	for (let r = 0; r < n; r++) {
		let n = 0;
		for (let s = e.offsets[r]; s < e.offsets[r + 1]; s++) {
			let c = e.indices[s], l = e.weights[s];
			for (let e = t.offsets[c]; e < t.offsets[c + 1]; e++) {
				let s = t.indices[e];
				a[s] !== r && (a[s] = r, i[s] = 0, o[n++] = s), i[s] += l * t.weights[e];
			}
		}
		if (d + n > c) {
			c = Math.max(c * 2, d + n);
			let e = new Uint32Array(c);
			e.set(l.subarray(0, d)), l = e;
			let t = new Float32Array(c);
			t.set(u.subarray(0, d)), u = t;
		}
		for (let e = 0; e < n; e++) {
			let t = o[e];
			l[d] = t, u[d] = i[t], d++;
		}
		s[r + 1] = d;
	}
	return {
		offsets: s,
		indices: l.slice(0, d),
		weights: u.slice(0, d),
		rowCount: n,
		controlVertexCount: r
	};
}
function u(e, t) {
	let n = e.positions.length / 3, r = c(n), i = e;
	for (let e = 0; e < t; e++) {
		let t = o(i);
		r = e === 0 ? {
			offsets: t.rows.offsets,
			indices: t.rows.indices,
			weights: Float32Array.from(t.rows.weights),
			rowCount: t.rows.rowCount,
			controlVertexCount: n
		} : l(t.rows, r), i = {
			positions: s(t.rows, i.positions),
			faceVertexCounts: t.faceVertexCounts,
			faceVertexIndices: t.faceVertexIndices,
			uvs: t.uvs,
			uvInterpolation: t.uvInterpolation,
			faceMaterialIndices: t.faceMaterialIndices,
			creases: t.creases,
			corners: t.corners
		};
	}
	return {
		mesh: i,
		table: r,
		levels: t
	};
}
function d(e, t, n) {
	return s(e, t, n);
}
//#endregion
//#region src/core/normals.ts
function f(e, t) {
	let n = e.positions.length / 3, r = e.positions, i = t ?? new Float32Array(n * 3);
	i.fill(0);
	let a = e.faceVertexCounts, o = e.faceVertexIndices, s = a.length, c = !0;
	for (let e = 0; e < s; e++) if (a[e] !== 4) {
		c = !1;
		break;
	}
	if (c) for (let e = 0; e < s; e++) {
		let t = e * 4, n = o[t] * 3, a = o[t + 1] * 3, s = o[t + 2] * 3, c = o[t + 3] * 3, l = r[s] - r[n], u = r[s + 1] - r[n + 1], d = r[s + 2] - r[n + 2], f = r[c] - r[a], p = r[c + 1] - r[a + 1], m = r[c + 2] - r[a + 2], h = u * m - d * p, g = d * f - l * m, _ = l * p - u * f;
		i[n] += h, i[n + 1] += g, i[n + 2] += _, i[a] += h, i[a + 1] += g, i[a + 2] += _, i[s] += h, i[s + 1] += g, i[s + 2] += _, i[c] += h, i[c + 1] += g, i[c + 2] += _;
	}
	else {
		let e = 0;
		for (let t = 0; t < s; t++) {
			let n = a[t], s = 0, c = 0, l = 0;
			for (let t = 0; t < n; t++) {
				let i = o[e + t] * 3, a = o[e + (t + 1) % n] * 3;
				s += (r[i + 1] - r[a + 1]) * (r[i + 2] + r[a + 2]), c += (r[i + 2] - r[a + 2]) * (r[i] + r[a]), l += (r[i] - r[a]) * (r[i + 1] + r[a + 1]);
			}
			for (let t = 0; t < n; t++) {
				let n = o[e + t] * 3;
				i[n] += s, i[n + 1] += c, i[n + 2] += l;
			}
			e += n;
		}
	}
	for (let e = 0; e < n; e++) {
		let t = i[e * 3], n = i[e * 3 + 1], r = i[e * 3 + 2], a = t * t + n * n + r * r;
		if (a > 1e-40) {
			let o = 1 / Math.sqrt(a);
			i[e * 3] = t * o, i[e * 3 + 1] = n * o, i[e * 3 + 2] = r * o;
		}
	}
	return i;
}
//#endregion
//#region src/core/skinning.ts
function p(e, t, n, r, i, a) {
	let o = e.length / 3, s = r, c = i;
	for (let r = 0; r < o; r++) {
		let i = e[r * 3], o = e[r * 3 + 1], l = e[r * 3 + 2], u = s[0] * i + s[4] * o + s[8] * l + s[12], d = s[1] * i + s[5] * o + s[9] * l + s[13], f = s[2] * i + s[6] * o + s[10] * l + s[14], p = s[3] * i + s[7] * o + s[11] * l + s[15], m = 0, h = 0, g = 0, _ = 0, v = 0;
		for (let e = 0; e < 4; e++) {
			let i = t.weights[r * 4 + e];
			if (i === 0) continue;
			v += i;
			let a = t.indices[r * 4 + e] * 16;
			m += i * (n[a] * u + n[a + 4] * d + n[a + 8] * f + n[a + 12] * p), h += i * (n[a + 1] * u + n[a + 5] * d + n[a + 9] * f + n[a + 13] * p), g += i * (n[a + 2] * u + n[a + 6] * d + n[a + 10] * f + n[a + 14] * p), _ += i * (n[a + 3] * u + n[a + 7] * d + n[a + 11] * f + n[a + 15] * p);
		}
		if (v === 0) {
			a[r * 3] = i, a[r * 3 + 1] = o, a[r * 3 + 2] = l;
			continue;
		}
		a[r * 3] = c[0] * m + c[4] * h + c[8] * g + c[12] * _, a[r * 3 + 1] = c[1] * m + c[5] * h + c[9] * g + c[13] * _, a[r * 3 + 2] = c[2] * m + c[6] * h + c[10] * g + c[14] * _;
	}
	return a;
}
//#endregion
//#region src/core/quadRecovery.ts
function m(e, t = {}) {
	let n = t.maxFaceAngle ?? 40 * Math.PI / 180, i = t.maxCornerDeviation ?? 40 * Math.PI / 180, a = t.uvTolerance ?? 1e-4, o = r(e), s = e.positions, c = e.faceVertexCounts.length, l = (t, n) => e.faceVertexIndices[o.faceOffsets[t] + n], u = (e, t) => {
		let n = l(e, 0) * 3, r = l(e, 1) * 3, i = l(e, 2) * 3, a = s[r] - s[n], o = s[r + 1] - s[n + 1], c = s[r + 2] - s[n + 2], u = s[i] - s[n], d = s[i + 1] - s[n + 1], f = s[i + 2] - s[n + 2];
		t[0] = o * f - c * d, t[1] = c * u - a * f, t[2] = a * d - o * u;
		let p = Math.hypot(t[0], t[1], t[2]);
		p > 1e-20 && (t[0] /= p, t[1] /= p, t[2] /= p);
	}, d = (e, t, n) => {
		let r = s[t * 3] - s[e * 3], i = s[t * 3 + 1] - s[e * 3 + 1], a = s[t * 3 + 2] - s[e * 3 + 2], o = s[n * 3] - s[e * 3], c = s[n * 3 + 1] - s[e * 3 + 1], l = s[n * 3 + 2] - s[e * 3 + 2], u = Math.hypot(r, i, a), d = Math.hypot(o, c, l);
		return u < 1e-20 || d < 1e-20 ? Math.PI : Math.acos(Math.max(-1, Math.min(1, (r * o + i * c + a * l) / (u * d))));
	}, f = (t, n) => {
		let r = (o.faceOffsets[t] + n) * 2;
		return [e.uvs[r], e.uvs[r + 1]];
	}, p = /* @__PURE__ */ new Float64Array(3), m = /* @__PURE__ */ new Float64Array(3), h = [];
	for (let t = 0; t < o.edgeCount; t++) {
		if (o.edgeFaceCounts[t] !== 2) continue;
		let r = o.edgeFaces[t * 2], s = o.edgeFaces[t * 2 + 1];
		if (r === s || e.faceVertexCounts[r] !== 3 || e.faceVertexCounts[s] !== 3 || e.faceMaterialIndices && e.faceMaterialIndices[r] !== e.faceMaterialIndices[s]) continue;
		let c = -1, g = -1;
		for (let e = 0; e < 3; e++) o.cornerEdges[o.faceOffsets[r] + e] === t && (c = e), o.cornerEdges[o.faceOffsets[s] + e] === t && (g = e);
		if (c < 0 || g < 0) continue;
		let _ = l(r, c), v = l(r, (c + 1) % 3), y = l(r, (c + 2) % 3);
		if (l(s, g) !== v || l(s, (g + 1) % 3) !== _) continue;
		let b = l(s, (g + 2) % 3);
		if (b === y) continue;
		if (e.uvs) {
			let [e, t] = f(r, c), [n, i] = f(s, (g + 1) % 3), [o, l] = f(r, (c + 1) % 3), [u, d] = f(s, g);
			if (Math.abs(e - n) > a || Math.abs(t - i) > a || Math.abs(o - u) > a || Math.abs(l - d) > a) continue;
		}
		u(r, p), u(s, m);
		let x = Math.acos(Math.max(-1, Math.min(1, p[0] * m[0] + p[1] * m[1] + p[2] * m[2])));
		if (x > n) continue;
		let S = [
			d(y, v, _),
			d(_, y, b),
			d(b, _, v),
			d(v, b, y)
		], C = 0;
		for (let e of S) C = Math.max(C, Math.abs(e - Math.PI / 2));
		C > i || h.push({
			edge: t,
			f0: r,
			f1: s,
			quad: [
				y,
				_,
				b,
				v
			],
			uvCorners: [
				o.faceOffsets[r] + (c + 2) % 3,
				o.faceOffsets[r] + c,
				o.faceOffsets[s] + (g + 2) % 3,
				o.faceOffsets[r] + (c + 1) % 3
			],
			score: x + C
		});
	}
	h.sort((e, t) => e.score - t.score);
	let g = new Int32Array(c).fill(-1), _ = [];
	for (let e of h) g[e.f0] !== -1 || g[e.f1] !== -1 || (g[e.f0] = _.length, g[e.f1] = _.length, _.push(e));
	let v = [], y = [], b = e.uvs ? [] : void 0, x = e.faceMaterialIndices ? [] : void 0, S = new Uint8Array(_.length);
	for (let t = 0; t < c; t++) {
		let n = g[t];
		if (x && e.faceMaterialIndices && (n === -1 || !S[n]) && x.push(e.faceMaterialIndices[t]), n !== -1) {
			if (S[n]) continue;
			S[n] = 1;
			let t = _[n];
			if (v.push(4), y.push(...t.quad), b && e.uvs) for (let n of t.uvCorners) b.push(e.uvs[n * 2], e.uvs[n * 2 + 1]);
		} else {
			let n = o.faceOffsets[t], r = e.faceVertexCounts[t];
			v.push(r);
			for (let t = 0; t < r; t++) y.push(e.faceVertexIndices[n + t]), b && e.uvs && b.push(e.uvs[(n + t) * 2], e.uvs[(n + t) * 2 + 1]);
		}
	}
	return {
		positions: e.positions,
		faceVertexCounts: new Uint32Array(v),
		faceVertexIndices: new Uint32Array(y),
		uvs: b ? new Float32Array(b) : void 0,
		faceMaterialIndices: x ? new Uint32Array(x) : void 0,
		creases: e.creases,
		corners: e.corners,
		uvInterpolation: e.uvInterpolation
	};
}
//#endregion
//#region src/three/extract.ts
function h(e, t = 1e-5) {
	let n = e.some((e) => e.getAttribute("uv")), r = e.length > 1, i = 1 / t, a = /* @__PURE__ */ new Map(), o = [], s = [], c = [], l = [], u = n ? [] : void 0, d = r ? [] : void 0;
	for (let t = 0; t < e.length; t++) {
		let n = e[t], r = n.getAttribute("position");
		if (!r) throw Error(`fromGeometries: input ${t} has no position attribute`);
		let f = n.getAttribute("uv"), p = n.getIndex(), m = new Uint32Array(r.count);
		for (let e = 0; e < r.count; e++) {
			let n = r.getX(e), l = r.getY(e), u = r.getZ(e), d = `${Math.round(n * i)}_${Math.round(l * i)}_${Math.round(u * i)}`, f = a.get(d);
			f === void 0 && (f = o.length / 3, a.set(d, f), o.push(n, l, u), s.push(e), c.push(t)), m[e] = f;
		}
		let h = (p ? p.count : r.count) / 3;
		for (let e = 0; e < h; e++) {
			let n = p ? p.getX(e * 3) : e * 3, r = p ? p.getX(e * 3 + 1) : e * 3 + 1, i = p ? p.getX(e * 3 + 2) : e * 3 + 2, a = m[n], o = m[r], s = m[i];
			a === o || o === s || s === a || (l.push(a, o, s), d?.push(t), u && (f ? u.push(f.getX(n), f.getY(n), f.getX(r), f.getY(r), f.getX(i), f.getY(i)) : u.push(0, 0, 0, 0, 0, 0)));
		}
	}
	return {
		mesh: {
			positions: new Float32Array(o),
			faceVertexCounts: new Uint32Array(l.length / 3).fill(3),
			faceVertexIndices: new Uint32Array(l),
			uvs: u ? new Float32Array(u) : void 0,
			faceMaterialIndices: d ? new Uint32Array(d) : void 0
		},
		cageToSource: new Uint32Array(s),
		cageToSourceGeometry: new Uint16Array(c)
	};
}
function g(e, t = 1e-5) {
	return h([e], t);
}
//#endregion
//#region src/three/geometry.ts
function _(e, t) {
	let n = /* @__PURE__ */ new Map(), r = 0;
	for (let i = 0; i < e.faceVertexCounts.length; i++) {
		let a = e.faceVertexCounts[i], o = e.faceMaterialIndices ? e.faceMaterialIndices[i] : 0, s = n.get(o);
		s || (s = [], n.set(o, s));
		for (let e = 1; e + 1 < a; e++) s.push(t(r), t(r + e), t(r + e + 1));
		r += a;
	}
	if (!e.faceMaterialIndices) return {
		index: n.get(0) ?? [],
		groups: null
	};
	let i = [], a = [];
	for (let [e, t] of [...n.entries()].sort((e, t) => e[0] - t[0])) {
		a.push({
			start: i.length,
			count: t.length,
			materialIndex: e
		});
		for (let e = 0; e < t.length; e++) i.push(t[e]);
	}
	return {
		index: i,
		groups: a
	};
}
function v(n) {
	let r = f(n), i = new t();
	if (!n.uvs) {
		let { index: t, groups: a } = _(n, (e) => n.faceVertexIndices[e]);
		if (i.setAttribute("position", new e(n.positions, 3)), i.setAttribute("normal", new e(r, 3)), i.setIndex(t), a) for (let e of a) i.addGroup(e.start, e.count, e.materialIndex);
		return {
			geometry: i,
			vertexSource: null
		};
	}
	let a = n.faceVertexIndices.length, o = n.positions.length / 3, s = new Uint32Array(a), c = new Uint32Array(o + 1);
	for (let e = 0; e < a; e++) c[n.faceVertexIndices[e] + 1]++;
	for (let e = 0; e < o; e++) c[e + 1] += c[e];
	let l = new Float32Array(a), u = new Float32Array(a), d = new Uint32Array(a), p = new Uint32Array(o), m = [], h = [], g = [], v = [];
	for (let e = 0; e < a; e++) {
		let t = n.faceVertexIndices[e], i = n.uvs[e * 2], a = n.uvs[e * 2 + 1], o = c[t], f = p[t], _ = -1;
		for (let e = 0; e < f; e++) if (l[o + e] === i && u[o + e] === a) {
			_ = d[o + e];
			break;
		}
		_ < 0 && (_ = m.length / 3, l[o + f] = i, u[o + f] = a, d[o + f] = _, p[t] = f + 1, m.push(n.positions[t * 3], n.positions[t * 3 + 1], n.positions[t * 3 + 2]), h.push(r[t * 3], r[t * 3 + 1], r[t * 3 + 2]), g.push(i, a), v.push(t)), s[e] = _;
	}
	let { index: y, groups: b } = _(n, (e) => s[e]);
	if (i.setAttribute("position", new e(new Float32Array(m), 3)), i.setAttribute("normal", new e(new Float32Array(h), 3)), i.setAttribute("uv", new e(new Float32Array(g), 2)), i.setIndex(y), b) for (let e of b) i.addGroup(e.start, e.count, e.materialIndex);
	return {
		geometry: i,
		vertexSource: new Uint32Array(v)
	};
}
function y(e) {
	return v(e).geometry;
}
function b(e, t, n) {
	let r = e.geometry.getAttribute("position"), i = e.geometry.getAttribute("normal");
	if (e.vertexSource) {
		let a = r.array, o = i.array;
		for (let r = 0; r < e.vertexSource.length; r++) {
			let i = e.vertexSource[r] * 3;
			a[r * 3] = t.positions[i], a[r * 3 + 1] = t.positions[i + 1], a[r * 3 + 2] = t.positions[i + 2], o[r * 3] = n[i], o[r * 3 + 1] = n[i + 1], o[r * 3 + 2] = n[i + 2];
		}
	}
	r.needsUpdate = !0, i.needsUpdate = !0;
}
function x(n) {
	let i = r(n), a = new Uint32Array(i.edgeCount * 2);
	a.set(i.edgeVertices);
	let o = new t();
	return o.setAttribute("position", new e(n.positions, 3)), o.setIndex(new e(a, 1)), o;
}
//#endregion
//#region src/three/SubdivSurfaceMesh.ts
var S = class e extends n {
	static lastBuildTimings = {};
	surface;
	cage;
	timings = {
		morphMs: 0,
		skinMs: 0,
		applyMs: 0
	};
	renderMesh;
	restPositions;
	normalsBuffer;
	skinSource;
	binding;
	morphSets;
	morphedPositions;
	constructor(t, n = {}) {
		let r = Array.isArray(t) ? t : [t];
		if (r.length === 0) throw Error("SubdivSurfaceMesh: no source meshes");
		let i = n.levels ?? 2, a = {}, o = performance.now(), s = (e) => {
			let t = performance.now();
			a[e] = t - o, o = t;
		}, c = h(r.map((e) => e.geometry), n.weldTolerance);
		s("extract");
		let l = c.mesh;
		n.recoverQuads !== !1 && (l = m(l, typeof n.recoverQuads == "object" ? n.recoverQuads : {})), s("quadRecovery");
		let d = u(l, i);
		s("stencils");
		let p = v(d.mesh);
		s("renderMesh"), e.lastBuildTimings = a;
		let g = n.material ?? (r.length === 1 ? r[0].material : r.map((e) => Array.isArray(e.material) ? e.material[0] : e.material));
		super(p.geometry, g), this.surface = d, this.cage = l, this.renderMesh = p, this.restPositions = l.positions.slice(), this.normalsBuffer = f(d.mesh);
		let { skinSource: _, binding: y } = w(r, c.cageToSource, c.cageToSourceGeometry);
		this.skinSource = _, this.binding = y, this.morphSets = C(r, c.cageToSource, c.cageToSourceGeometry), this.morphedPositions = this.morphSets.length > 0 ? this.restPositions.slice() : null;
	}
	get isSkinned() {
		return this.binding !== null;
	}
	update() {
		this.updateCage(), this.evaluateSurface();
	}
	updateCage() {
		let e = this.restPositions;
		if (this.morphedPositions) {
			let t = performance.now(), n = this.morphedPositions;
			n.set(this.restPositions);
			for (let e of this.morphSets) {
				let t = e.mesh.morphTargetInfluences;
				if (t) for (let r = 0; r < e.deltas.length; r++) {
					let i = t[r] ?? 0;
					if (Math.abs(i) < 1e-6) continue;
					let a = e.deltas[r];
					for (let t = 0; t < e.cageVertices.length; t++) {
						let r = e.cageVertices[t] * 3;
						n[r] += i * a[t * 3], n[r + 1] += i * a[t * 3 + 1], n[r + 2] += i * a[t * 3 + 2];
					}
				}
			}
			e = n, this.timings.morphMs = performance.now() - t;
		}
		let t = this.skinSource;
		if (this.binding && t && t.skeleton.boneMatrices) {
			t.skeleton.update();
			let n = performance.now();
			p(e, this.binding, t.skeleton.boneMatrices, t.bindMatrix.elements, t.bindMatrixInverse.elements, this.cage.positions), this.timings.skinMs = performance.now() - n;
		} else e !== this.restPositions && this.cage.positions.set(e);
	}
	evaluateSurface() {
		let e = performance.now();
		d(this.surface.table, this.cage.positions, this.surface.mesh.positions), f(this.surface.mesh, this.normalsBuffer), b(this.renderMesh, this.surface.mesh, this.normalsBuffer), this.timings.applyMs = performance.now() - e;
	}
};
function C(e, t, n) {
	let r = [];
	for (let i = 0; i < e.length; i++) {
		let a = e[i].geometry, o = a.morphAttributes.position;
		if (!o || o.length === 0) continue;
		let s = [];
		for (let e = 0; e < t.length; e++) n[e] === i && s.push(e);
		if (s.length === 0) continue;
		let c = a.getAttribute("position"), l = a.morphTargetsRelative, u = o.map((e) => {
			let n = new Float32Array(s.length * 3);
			for (let r = 0; r < s.length; r++) {
				let i = t[s[r]];
				n[r * 3] = e.getX(i) - (l ? 0 : c.getX(i)), n[r * 3 + 1] = e.getY(i) - (l ? 0 : c.getY(i)), n[r * 3 + 2] = e.getZ(i) - (l ? 0 : c.getZ(i));
			}
			return n;
		});
		r.push({
			mesh: e[i],
			cageVertices: new Uint32Array(s),
			deltas: u
		});
	}
	return r;
}
function w(e, t, n) {
	let r = e.filter((e) => e.isSkinnedMesh);
	if (r.length === 0) return {
		skinSource: null,
		binding: null
	};
	let i = r[0].skeleton;
	for (let e of r) {
		if (e.skeleton !== i) return console.warn("SubdivSurfaceMesh: sources use different skeletons; rendering statically."), {
			skinSource: null,
			binding: null
		};
		if (!e.geometry.getAttribute("skinIndex") || !e.geometry.getAttribute("skinWeight")) return console.warn("SubdivSurfaceMesh: skinned source missing skin attributes; rendering statically."), {
			skinSource: null,
			binding: null
		};
	}
	let a = new Uint16Array(t.length * 4), o = new Float32Array(t.length * 4);
	for (let r = 0; r < t.length; r++) {
		let i = e[n[r]], s = i.geometry.getAttribute("skinIndex"), c = i.geometry.getAttribute("skinWeight");
		if (!s || !c) continue;
		let l = t[r];
		a[r * 4] = s.getX(l), a[r * 4 + 1] = s.getY(l), a[r * 4 + 2] = s.getZ(l), a[r * 4 + 3] = s.getW(l), o[r * 4] = c.getX(l), o[r * 4 + 1] = c.getY(l), o[r * 4 + 2] = c.getZ(l), o[r * 4 + 3] = c.getW(l);
	}
	return {
		skinSource: r[0],
		binding: {
			indices: a,
			weights: o
		}
	};
}
//#endregion
export { b as a, m as c, d, u as f, r as g, i as h, x as i, p as l, o as m, v as n, g as o, s as p, y as r, h as s, S as t, f as u };

//# sourceMappingURL=SubdivSurfaceMesh-BLcxZGlX.js.map